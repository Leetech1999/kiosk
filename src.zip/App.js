import React, { useState } from 'react';
import './App.css';
import FloorMenu from './components/FloorMenu';
import FirstFloor from './components/FirstFloor';
import SecondFloor from './components/SecondFloor';
import ThirdFloor from './components/ThirdFloor';

function App() {
  const [selectedFloor, setSelectedFloor] = useState('first');
  const changeFloor = (floor) =>{
    setSelectedFloor(floor);
  }
  console.log( selectedFloor );
  const renderFloorComponent=()=>{
    switch(selectedFloor){
      case 'first':
        return <FirstFloor />;
      case 'second':
        return <SecondFloor />;
      case 'third':
        return <ThirdFloor />;
      default:
        return(<div><p>왼쪽에서 층을 선택해주세요.</p></div>)
    }
  }

  return (
    <div className="App">
      <div className="left-panel">
        <FloorMenu onSelectFloor={changeFloor}/>
      </div>
      <div className="right-panel">
        {renderFloorComponent()}
      </div>
    </div>
  );
}

export default App;
