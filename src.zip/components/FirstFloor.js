import React from 'react';

function FirstFloor(){
  return(
    <div>
      <h2> 1층 안내도 </h2>
    </div>
  )
}

export default FirstFloor;