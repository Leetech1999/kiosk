import React from 'react';

function FloorMenu({onSelectFloor}){
  return(
    <div>
      <h2>층 선택</h2>
      <ul>
        <li><button onClick={()=> onSelectFloor('first') }>1층</button></li>
        <li><button onClick={()=> onSelectFloor('second') }>2층</button></li>
        <li><button onClick={()=> onSelectFloor('third') }>3층</button></li>
      </ul>
    </div>
  )
}

export default FloorMenu;