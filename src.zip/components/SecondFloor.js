import React from 'react';

function SecondFloor(){
  return(
    <div>
      <h2> 2층 안내도 </h2>
    </div>
  )
}

export default SecondFloor;