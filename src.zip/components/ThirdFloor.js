import React from 'react';

function ThirdFloor(){
  return(
    <div>
      <h2> 3층 안내도 </h2>
    </div>
  )
}

export default ThirdFloor;